# Scoreline brand kit · v1.0 · October 2026

Design: Turinoz. The full guide is `scoreline-brand-book.pdf`.

## Folders

- `01-mark` · the mark in color, plus one-color versions for dark (`ink`) and light (`chalk`) grounds.
- `02-lockup` · mark + name. `night` for dark grounds, `white` for light grounds, `ink` / `chalk` in one color.
- `03-icon` · app icon (rounded square), avatar (circle), favicon.
- `04-motion` · Lift and Roll as Lottie (1080 × 1080, 60 fps, loops) and MP4 previews.
- `05-tokens` · colors, type and motion for code (CSS custom properties and JSON).

## Rules in one breath

- Bars left to right: Dusk, Violet, Floodlight. Never reorder, rotate, stretch, flatten or level them.
- Clear space: one bar width on every side. Minimum size: 16 px tall on screen, 6 mm in print.
- On the violet field gradient, use the one-color mark.
- Type: Hanken Grotesk. Medium for names and scores, Regular for text, tabular numbers.

## Motion

| | Ease | Duration | Delays | Hold |
|---|---|---|---|---|
| Lift | cubic-bezier(.65, 0, .35, 1) | 800 ms | L 0 · M 180 · R 440 ms | 1000 ms |
| Roll | cubic-bezier(.802, .057, .35, 1) | 800 ms | M 0 · L 160 · R 160 ms | 500 ms |

Sides go up and come back from below, the middle goes down and comes back from above.
