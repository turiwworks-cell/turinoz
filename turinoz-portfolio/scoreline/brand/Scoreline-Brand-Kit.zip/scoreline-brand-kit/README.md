# Scoreline brand kit · v1.0 · October 2026

Design: Turinoz. The full guide is `scoreline-brand-book.pdf`.

## Folders

- `01-mark` · the mark in color, plus one-color versions for dark (`ink`) and light (`chalk`) grounds.
- `02-lockup` · mark + name. `night` for dark grounds, `white` for light grounds, `ink` / `chalk` in one color.
- `03-icon` · app icon (rounded square), avatar (circle), favicon.
- `04-motion` · Lift and Roll as Lottie (1080 × 1080, 60 fps, loops) and MP4 previews.
- `05-tokens` · colors, type and motion for code (CSS custom properties and JSON).
- `06-icons` · the app's 20 icons at their app size. `events` sit on a disc; `interface` icons are 1.5 strokes in `currentColor`.

## Rules

- Bars left to right: Dusk, Violet, Floodlight. Never reorder, rotate, stretch, flatten or level them.
- Clear space: one bar width on every side. Minimum size: 16 px on screen, 6 mm in print.
- On the violet field gradient, use the one-color mark.
- Type: Hanken Grotesk. Light 300 for the match clock, Regular 400 for text, Medium 500 for values and the wordmark, Semibold 600 for names, Bold 700 for scores. Numbers are tabular.

## Motion

| | Ease | Duration | Delays | Where |
|---|---|---|---|---|
| Lift | cubic-bezier(.65, 0, .35, 1) | 800 ms | L 0 · M 180 · R 440 ms | idle, every 5 s |
| Roll | cubic-bezier(.802, .057, .35, 1) | 800 ms | M 0 · L 160 · R 160 ms | hover, each new section |

Sides go up and come back from below, the middle goes down and comes back from above.
