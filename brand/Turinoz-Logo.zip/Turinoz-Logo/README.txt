TURINOZ · LOGO FILES

Start with Turinoz-Brand-Guide.pdf (6 pages).

WHICH FILE WHERE
Dribbble, Instagram, LinkedIn, X, Behance profile picture
  02_Social/Profile/turinoz-profile-night-1080.png  (paper version for dark UIs)
Dribbble shot of the logo        02_Social/Dribbble-shot-1600x1200-*.png
X header                         02_Social/Covers/x-header-1500x500-*.png
LinkedIn cover                   02_Social/Covers/linkedin-cover-1584x396-night.png
YouTube banner                   02_Social/Covers/youtube-banner-2560x1440-night.png
Behance banner                   02_Social/Covers/behance-banner-3200x410-night.png
Website favicon and app icons    03_Web/ (favicon.ico, favicon.svg, apple-touch-icon.png, icon-192/512.png)
Link previews (Open Graph)       03_Web/og-image-1200x630.png
Phone or app icon                04_App-Icon/turinoz-app-icon-1024.png
Decks, proposals, invoices       01_Logo/SVG/turinoz-lockup-on-light.svg (or the PNG in 01_Logo/PNG)
Dark backgrounds, video          01_Logo/*on-dark*, turinoz-badge-paper, turinoz-crown-paper
Intros and reels                 05_Motion/ (GIF, MP4, animated SVG, Lottie JSON)

RULES
- The crown is always a line. Never fill it.
- One color: Paper #F1F0EC, Night #0C0C0B.
- Under 64 px use the small cuts (badge-small-32 / badge-small-16), never a shrunk master.
- Clear space: a quarter of the badge diameter on every side.
- Name type: Archivo SemiBold (600), tracking -1%.

Vector masters are in 01_Logo/SVG. Every PNG in 01_Logo/PNG has a transparent background.
